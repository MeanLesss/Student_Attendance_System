namespace FontEnumGenerator
{
    internal class FontEnumItem
    {
        public string Class { get; set; }
        public string Code { get; set; }
    }
}