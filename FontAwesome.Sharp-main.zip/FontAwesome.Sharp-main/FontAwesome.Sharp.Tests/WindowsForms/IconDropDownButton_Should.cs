
namespace FontAwesome.Sharp.Tests.WindowsForms
{
    // ReSharper disable once InconsistentNaming
    public class IconDropDownButton_Should : FormsIconTestBase<IconDropDownButton>
    {
    }
}
