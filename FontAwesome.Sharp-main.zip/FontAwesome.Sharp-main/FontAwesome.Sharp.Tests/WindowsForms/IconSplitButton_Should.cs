
namespace FontAwesome.Sharp.Tests.WindowsForms
{
    // ReSharper disable once InconsistentNaming
    public class IconSplitButton_Should : FormsIconTestBase<IconSplitButton>
    {
    }
}
