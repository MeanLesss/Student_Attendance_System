
namespace FontAwesome.Sharp.Tests.WindowsForms
{
    // ReSharper disable once InconsistentNaming
    public class IconButton_Should : FormsIconTestBase<IconButton>
    {
    }
}
