
namespace FontAwesome.Sharp.Tests.WindowsForms
{
    // ReSharper disable once InconsistentNaming
    public class IconMenuItem_Should : FormsIconTestBase<IconMenuItem>
    {
    }
}
