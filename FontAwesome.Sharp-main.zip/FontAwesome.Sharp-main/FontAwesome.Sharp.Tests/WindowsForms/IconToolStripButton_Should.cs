
namespace FontAwesome.Sharp.Tests.WindowsForms
{
    // ReSharper disable once InconsistentNaming
    public class IconToolStripButton_Should : FormsIconTestBase<IconToolStripButton>
    {
    }
}
