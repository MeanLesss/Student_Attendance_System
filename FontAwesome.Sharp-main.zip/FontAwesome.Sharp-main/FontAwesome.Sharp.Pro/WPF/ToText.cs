namespace FontAwesome.Sharp.Pro
{
    public class ToText : ToTextBase<ProIcons>
    {
        public ToText(ProIcons icon) : base(icon)
        {
        }
    }
}
