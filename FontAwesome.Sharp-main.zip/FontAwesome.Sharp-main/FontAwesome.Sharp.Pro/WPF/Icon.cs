namespace FontAwesome.Sharp.Pro
{
    public class Icon : IconBase<IconBlock, ProIcons>
    {
        public Icon(ProIcons icon) : base(icon)
        {
        }
    }
}
