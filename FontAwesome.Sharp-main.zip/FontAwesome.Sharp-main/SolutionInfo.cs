﻿using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyDescription("FontAwesome.Sharp")]
[assembly: AssemblyProduct("FontAwesome.Sharp")]

#if DEBUG
[assembly: AssemblyConfiguration("Debug")]
#else
[assembly: AssemblyConfiguration("Release")]
#endif

[assembly: AssemblyCompany("Awesome Inc.")]
[assembly: AssemblyCopyright("Copyright © Awesome Inc. 2015-2019")]
[assembly: AssemblyTrademark("Awesome Inc.")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en", UltimateResourceFallbackLocation.MainAssembly)]

//------ Updated by cake/GitVersion ----------------
[assembly: AssemblyVersion("5.11.3.0")]
[assembly: AssemblyFileVersion("5.11.3.0")]
[assembly: AssemblyInformationalVersion("5.11.3-netcore.1+17.Branch.netcore.Sha.c359cc1c1795bc46e03778eb9338bbee9aa10edf")]
