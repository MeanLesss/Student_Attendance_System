﻿namespace TestWpf
{
    public partial class App
    {
    }
}