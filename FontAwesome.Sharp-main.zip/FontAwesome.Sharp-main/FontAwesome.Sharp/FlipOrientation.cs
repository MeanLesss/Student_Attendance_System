namespace FontAwesome.Sharp
{
    public enum FlipOrientation
    {
        Normal = 0,
        Horizontal,
        Vertical
    }
}