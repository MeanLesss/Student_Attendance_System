namespace FontAwesome.Sharp
{
    public class ToText : ToTextBase<IconChar>
    {
        public ToText(IconChar icon) : base(icon)
        {
        }
    }
}
