namespace FontAwesome.Sharp
{
    public interface IHaveIconFont
    {
        IconFont IconFont { get; set; }
    }
}
