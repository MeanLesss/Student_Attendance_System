using System.Runtime.CompilerServices;
using System.Windows.Markup;

[assembly: XmlnsPrefix("http://schemas.awesome.incremented/wpf/xaml/fontawesome.sharp.material", "faMaterial")]
[assembly: XmlnsDefinition("http://schemas.awesome.incremented/wpf/xaml/fontawesome.sharp.material", "FontAwesome.Sharp.Material")]
[assembly: InternalsVisibleTo("FontAwesome.Sharp.Tests, PublicKey=00240000048000009400000006020000002400005253413100040000010001009d3c7c4ace17c970a11cd07316f19e5a7d0a982813b1195cd07422c54390d8db3722832fdb3e196a9e569b66d2d2839de470579114dbab6c66ed8e50f018b8029eb9c3698cbd29d6d4f737994e110df76a7c779c40598ca9f626b1df7046fce4d2e48827cd993032105dcf7e9bbc4054d51bf84c9a02f72df76f26f5c7ff0dc5")]
