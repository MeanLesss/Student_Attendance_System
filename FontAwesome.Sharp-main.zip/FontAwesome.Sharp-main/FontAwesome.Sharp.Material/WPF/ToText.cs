namespace FontAwesome.Sharp.Material
{
    public class ToText : ToTextBase<MaterialIcons>
    {
        public ToText(MaterialIcons icon) : base(icon)
        {
        }
    }
}