namespace FontAwesome.Sharp.Material
{
    public class Icon : IconBase<IconBlock, MaterialIcons>
    {
        public Icon(MaterialIcons icon) : base(icon)
        {
        }
    }
}
