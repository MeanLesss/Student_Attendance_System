namespace FontAwesome.Sharp.Material
{
    public class IconBlock : IconBlockBase<MaterialIcons>
    {
        public IconBlock() : base(MaterialDesignFont.Wpf.Value)
        {
        }
    }
}
