namespace FontAwesome.Sharp.Material
{
    public class MaterialToolStripButton : IconToolStripButton<MaterialIcons>
    {
        public MaterialToolStripButton() : base(MaterialDesignFont.WinForms.Value)
        {
        }
    }
}
