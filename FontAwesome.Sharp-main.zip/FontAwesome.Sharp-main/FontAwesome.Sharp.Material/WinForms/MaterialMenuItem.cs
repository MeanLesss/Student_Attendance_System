namespace FontAwesome.Sharp.Material
{
    public class MaterialMenuItem : IconMenuItem<MaterialIcons>
    {
        public MaterialMenuItem() : base(MaterialDesignFont.WinForms.Value)
        {
        }
    }
}
