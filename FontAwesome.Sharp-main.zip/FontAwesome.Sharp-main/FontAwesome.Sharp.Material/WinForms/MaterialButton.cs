namespace FontAwesome.Sharp.Material
{
    public class MaterialButton : IconButton<MaterialIcons>
    {
        public MaterialButton() : base(MaterialDesignFont.WinForms.Value)
        {
        }
    }
}
