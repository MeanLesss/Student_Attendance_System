namespace FontAwesome.Sharp.Material
{
    public class MaterialSplitButton : IconSplitButton<MaterialIcons>
    {
        public MaterialSplitButton() : base(MaterialDesignFont.WinForms.Value)
        {
        }
    }
}
