namespace FontAwesome.Sharp.Material
{
    public class MaterialPictureBox : IconPictureBox<MaterialIcons>
    {
        public MaterialPictureBox() : base(MaterialDesignFont.WinForms.Value)
        {
        }
    }
}
