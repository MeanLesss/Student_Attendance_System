namespace FontAwesome.Sharp.Material
{
    public class MaterialDropDownButton : IconDropDownButton<MaterialIcons>
    {
        public MaterialDropDownButton() : base(MaterialDesignFont.WinForms.Value)
        {
        }
    }
}
